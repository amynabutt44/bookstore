import React, { useState, useEffect } from "react";
import axios from "axios";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import Cards from "./Cards";

function FreeBook() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/books")
      .then((response) => {
        setBooks(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching books:", error);
        setLoading(false);
      });
  }, []);

  const settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <div className="max-w-screen-2xl container mx-auto md:px-20 px-4 text-center mt-12">
      <div>
        <h1 className="text-5xl font-bold text-pink-600 pb-6 transform hover:scale-105 transition-all duration-300 ease-in-out uppercase tracking-wider">
          BOOKS
        </h1>
        <p className="text-lg text-gray-700 mx-auto max-w-4xl leading-relaxed">
          Explore an extensive collection of books for all interests and age groups! From exciting adventures to captivating dramas, our library has something for everyone. Whether you're searching for the perfect fictional story or looking to dive into a compelling narrative, you’ll find it here. Start your reading journey today!
        </p>
      </div>

      <div className="mt-12">
        {loading ? (
          <p className="text-lg text-gray-500">Loading books...</p>
        ) : (
          <Slider {...settings}>
            {books.map((item) => (
              <Cards item={item} key={item._id} />
            ))}
          </Slider>
        )}
      </div>
    </div>
  );
}

export default FreeBook;
