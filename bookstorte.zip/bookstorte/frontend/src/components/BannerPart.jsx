import React from "react";
import { Link } from "react-router-dom";  // Import Link from react-router-dom

const App = () => {
    return (
        <div className="flex flex-col md:flex-row items-center justify-between px-6 py-12 md:px-16 bg-gray-100 min-h-screen text-gray-800">
            {/* Left Content (65% Width for Text) */}
            <div className="w-full md:w-2/3 text-center md:text-left space-y-6">
                <h1 className="text-4xl font-bold leading-tight">
                    Welcome to <span className="text-pink-500">Bookstore Hub</span>, your
                    gateway to exploring{" "}
                    <span className="text-pink-600 font-extrabold">
                        new knowledge every day!
                    </span>
                </h1>
                <p className="text-gray-700">
                    Discover a vast collection of books, resources, and learning materials
                    tailored to ignite your passion for reading and self-growth. Join us to
                    explore new genres, authors, and ideas that shape the world.
                </p>
                <div>
                    <p className="text-lg text-gray-600">
                        Start your journey today and explore a world of knowledge.
                    </p>
                </div>
                <Link to="/course">
                    <button className="bg-pink-500 text-white px-8 py-3 rounded-lg text-lg hover:bg-pink-600">
                        Explore More
                    </button>
                </Link>
            </div>

            {/* Right Content (35% Width for Image) */}
            <div className="w-full md:w-1/3 mt-8 md:mt-0">
                <img
                    src="/image/cover_image.avif"
                    alt="Books and learning resources"
                    className="w-full h-auto"
                />
            </div>
        </div>
    );
};

export default App;
