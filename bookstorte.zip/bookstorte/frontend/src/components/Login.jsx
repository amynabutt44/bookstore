import React, { useState } from 'react';

export default function Login({ closeModal }) {
  const [isLogin, setIsLogin] = useState(true); // State to toggle between Login and Signup forms

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-80">
        <h2 className="text-2xl font-bold mb-4">{isLogin ? 'Login' : 'Signup'}</h2>
        
        {/* Toggle between Login and Signup */}
        {isLogin ? (
          // Login Form
          <form>
            <input
              type="text"
              placeholder="Username"
              className="input input-bordered w-full mb-4"
            />
            <input
              type="password"
              placeholder="Password"
              className="input input-bordered w-full mb-4"
            />
            <button type="submit" className="btn bg-pink-500 text-white w-full">
              Submit
            </button>
          </form>
        ) : (
          // Signup Form
          <form>
            <input
              type="text"
              placeholder="Username"
              className="input input-bordered w-full mb-4"
            />
            <input
              type="email"
              placeholder="Email"
              className="input input-bordered w-full mb-4"
            />
            <input
              type="password"
              placeholder="Password"
              className="input input-bordered w-full mb-4"
            />
            <button type="submit" className="btn bg-pink-500 text-white w-full">
              Sign Up
            </button>
          </form>
        )}

        <div className="mt-4">
          {/* Toggle button for switching between Login and Signup */}
          <button
            className="text-blue-500"
            onClick={() => setIsLogin(!isLogin)}
          >
            {isLogin ? 'Create an account?' : 'Already have an account?'}
          </button>
        </div>

        <button
          className="mt-4 text-pink-500"
          onClick={closeModal}
        >
          Close
        </button>
      </div>
    </div>
  );
}
