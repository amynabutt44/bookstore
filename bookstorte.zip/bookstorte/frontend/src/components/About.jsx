import React from 'react';

const About = () => {
  return (
    <div className="max-w-screen-lg mx-auto px-6 py-12 pt-20"> {/* Adjust pt-20 for proper spacing below Navbar */}
      <div className="text-center mb-16">
        <h1 className="text-4xl font-semibold text-gray-800">About Us</h1>
        <p className="text-lg text-gray-600 mt-2">Who We Are and What We Do</p>
      </div>
      
      <div className="space-y-12">
        <section>
          <h2 className="text-2xl font-semibold text-gray-800">Our Mission</h2>
          <p className="text-gray-600 mt-2">
            Our mission is to provide top-notch services that connect users with local professionals
            in a variety of fields. We are committed to quality, convenience, and customer satisfaction,
            ensuring that every user finds the service they need quickly and efficiently.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-800">Our Vision</h2>
          <p className="text-gray-600 mt-2">
            We envision a world where technology bridges the gap between service providers and customers,
            offering seamless, real-time solutions for all your service needs.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-800">Our Values</h2>
          <ul className="list-disc pl-5 text-gray-600 mt-2 space-y-2">
            <li>Integrity: We uphold the highest standards of professionalism and transparency.</li>
            <li>Innovation: We continuously strive for creative solutions to enhance user experience.</li>
            <li>Customer-Centric: We prioritize customer satisfaction above all else.</li>
            <li>Community: We support local businesses and promote the growth of small enterprises.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-800">Meet the Team</h2>
          <p className="text-gray-600 mt-2">
            Our team is made up of passionate professionals dedicated to improving the way people access services
            in their local areas. With a diverse set of skills in technology, customer service, and business,
            we work together to deliver the best possible experience for our users.
          </p>
        </section>
      </div>
    </div>
  );
}

export default About;
