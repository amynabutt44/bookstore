import React, { useState } from "react";

// Modal component to show the full description
function Modal({ isOpen, onClose, description }) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
      <div className="bg-white p-6 rounded-lg w-1/3 shadow-lg relative">
        <h2 className="text-xl font-bold mb-4">Description</h2>
        <p>{description}</p>
        <button
          onClick={onClose}
          className="mt-4 bg-pink-500 text-white px-4 py-2 rounded-full"
        >
          Close
        </button>
      </div>
    </div>
  );
}

function Cards({ item }) {
  const [isModalOpen, setIsModalOpen] = useState(false); // State to manage modal visibility

  const handleCardClick = () => {
    setIsModalOpen(true); // Open the modal on card click
  };

  const closeModal = () => {
    setIsModalOpen(false); // Close the modal
  };

  return (
    <div className="mt-4 my-3 p-3">
      <div
        className="card w-92 bg-gray-100 text-gray-800 shadow-xl hover:scale-105 duration-200 border border-gray-300 cursor-pointer"
        onClick={handleCardClick} // Trigger modal on card click
      >
        <figure className="relative">
          <img
            src={`http://localhost:5000/${item.image}`} // Dynamically load book image
            alt={item.name}
            className="w-full h-56 object-cover rounded-t-lg" // Professional image styling
          />
        </figure>
        <div className="card-body">
          <h2 className="card-title text-gray-800">
            {item.title} {/* Dynamically display book title */}
            <div className="badge badge-secondary bg-pink-500">{item.category}</div>
          </h2>
         
          <div className="card-actions justify-between">
            <div className="badge badge-outline text-gray-700">${item.price}</div> {/* Display price */}
          </div>
        </div>
      </div>

      {/* Modal to show full description */}
      <Modal isOpen={isModalOpen} onClose={closeModal} description={item.description} />
    </div>
  );
}

export default Cards;
