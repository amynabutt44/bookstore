import React, { useState, useEffect } from "react";
import axios from "axios";
import Cards from "./Cards";

function Course() {
  const [courses, setCourses] = useState([]); // Initialize state to hold course data
  const [loading, setLoading] = useState(true); // Loading state to show a spinner or message
  const [error, setError] = useState(null); // Error state to handle failed API requests

  // Fetch course data from the API
  useEffect(() => {
    axios
      .get("http://localhost:5000/api/books") // Replace with your actual API URL
      .then((response) => {
        setCourses(response.data); // Set courses data to state
        setLoading(false); // Set loading to false after data is fetched
      })
      .catch((err) => {
        setError("Failed to fetch courses. Please try again later.");
        setLoading(false);
      });
  }, []); // Empty array means this will run only once when the component mounts

  if (loading) {
    return (
      <div className="text-center mt-28">
        <p>Loading courses...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center mt-28">
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="max-w-screen-2xl container mx-auto md:px-20 px-4">
      <div className="mt-28 items-center justify-center text-center">
        <h1 className="text-2xl md:text-4xl">
          Explore Our <span className="text-pink-500">Courses</span>
        </h1>
        <p className="mt-12">
          Choose from a variety of courses designed to boost your skills and knowledge.
          Whether you are a beginner or looking to advance, we have something for you.
        </p>
      </div>

      <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 gap-y-8">
        {courses.map((course) => (
          <div key={course.id} className="w-full h-96">
            <Cards item={course} />
          </div>
        ))}
      </div>
    </div>
  );
}

export default Course;
