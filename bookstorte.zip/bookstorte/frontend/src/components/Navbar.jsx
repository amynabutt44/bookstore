import React from 'react';
import { Link } from 'react-router-dom';  // Import Link from react-router-dom

export default function Navbar() {
  const Navitems = (
    <>
      <li><Link to="/" className="text-lg font-bold">Home</Link></li>
      <li><Link to="/course" className="text-lg font-bold">Course</Link></li>
      <li><Link to="/contact" className="text-lg font-bold">Contact</Link></li>
      <li><Link to="/about" className="text-lg font-bold">About</Link></li>
    </>
  );

  return (
    <div className="font-sans">
      <div className="navbar fixed top-0 w-full z-50 bg-base-100 shadow-lg">
        {/* Navbar Start */}
        <div className="navbar-start">
          <div className="dropdown">
            <div
              tabIndex={0}
              role="button"
              className="btn btn-ghost lg:hidden"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M4 6h16M4 12h8m-8 6h16"
                />
              </svg>
            </div>
            <ul
              tabIndex={0}
              className="menu menu-sm dropdown-content bg-base-100 rounded-box z-[1] mt-3 w-52 p-2 shadow"
            >
              {Navitems}
            </ul>
          </div>
          {/* Use Link for navigation, no browser confirmation */}
          <Link to="/" className="text-2xl cursor-pointer font-bold ml-8 text-pink-600">BookStore</Link>
        </div>

        <div className="navbar-center hidden lg:flex">
          <ul className="menu menu-horizontal px-1 justify-center space-x-4">
            {Navitems}
          </ul>
        </div>

        <div className="navbar-end flex items-center space-x-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Search"
              className="input input-bordered pl-10 pr-4"
            />
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-600"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M11 18a7 7 0 1 1 7-7 7 7 0 0 1-7 7zM21 21l-4.35-4.35"
              />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}
