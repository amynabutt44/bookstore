import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';  // Ensure Routes and Route are imported
import Home from './home/Home';

import Courses from './courses/Courses';
import ContactUs from './contact/ContactUs';
import AboutUs from './AboutUs/AboutUs';



export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/course" element={<Courses />} />
        <Route path="/about" element={<AboutUs/>}/>
        <Route path="/contact" element={<ContactUs />} />
        
      </Routes>
    </BrowserRouter>
  );
}
