import React from 'react'
import Navbar from '../components/Navbar'
import BannerPart from '../components/BannerPart'
import  FreeBook from '../components/FreeBook'
import Footer from '../components/Footer'

export default function Home() {
    return (
        <>
            <div >
                <Navbar />
                <BannerPart />
                <FreeBook />
                <Footer />

            </div>
        </>

    )
}
