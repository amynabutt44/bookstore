// bookRoutes.js
const express = require('express');
const multer = require('multer');
const Book = require('../models/Books'); // Import the Book model
const router = express.Router();

// Multer setup for image upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Save images in the uploads folder
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname); // Unique file name
  },
});

const upload = multer({ storage });

// GET route to fetch all books
router.get('/', async (req, res) => {
  try {
    const books = await Book.find(); // Fetch all books from the database
    res.status(200).json(books); // Send books as response
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch books', error: err.message });
  }
});

// POST route to add a new book
router.post('/', upload.single('image'), async (req, res) => {
  const { title, author, description, price, category } = req.body;
  const image = req.file ? req.file.path : null; // Get the image path

  try {
    const newBook = new Book({
      title,
      author,
      description,
      price,
      image,
      category,
    });

    await newBook.save(); // Save the book to the database
    res.status(201).json({ message: 'Book added successfully', book: newBook });
  } catch (err) {
    res.status(500).json({ message: 'Failed to add book', error: err.message });
  }
});

module.exports = router; // Export the router
