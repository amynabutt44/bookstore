const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({
  title: { type: String, required: true }, // Book title
  author: { type: String, required: true }, // Author name
  description: { type: String, required: true }, // Book description
  price: { type: Number, required: true }, // Price of the book
  image: { type: String, required: true }, // Path to the uploaded image
  category: { type: String, required: true }, // Book category (e.g., Fiction, Science)
  publishedDate: { type: Date, default: Date.now }, // Date when the book was added
});

// Export the Book model
module.exports = mongoose.model('Book', bookSchema);
